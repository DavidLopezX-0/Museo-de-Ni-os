-- Proyecto para Arquitectura de Datos Integral
Create Database Museo;
Go

Use Museo;
Go

-- ============================================
-- Tabla: Visitante
Create Table Visitante (
    Id_Visitante Int Primary Key Identity(1,1),
    TipoVisitante Nvarchar(40) Not Null Check (TipoVisitante In ('Ni�o', 'Adolescente', 'Adulto joven', 'Adulto mayor', 'Primera infancia'))
);
Go

-- ============================================
-- Tabla: Boleto
Create Table Boleto (
    Id_Boleto Int Primary Key Identity(1,1),
    TipoBoleto Nvarchar(20) Not Null Check (TipoBoleto In ('Ni�o', 'Adulto')),
    FechaCompra Date Not Null Default(Getdate()),
    CostoTotal Decimal(8,2) Not Null,
    MetodoPago Nvarchar(30) Not Null,
    Id_Visitante Int Not Null,
    Foreign Key (Id_Visitante) References Visitante(Id_Visitante)
);
Go

-- ============================================
-- Tabla: Empleado
Create Table Empleado (
    Id_Empleado Int Primary Key Identity(1,1),
    Nombre Nvarchar(50) Not Null,
    Apellido Nvarchar(50) Not Null,
    TipoEmpleado Nvarchar(40) Not Null Check (TipoEmpleado In ('Equipo de Sala', 'Gu�a Educativo', 'Mantenimiento', 'Limpieza')),
    Cargo Nvarchar(60) Not Null
);
Go

-- ============================================
-- Tabla: Patrocinador
Create Table Patrocinador (
    Id_Patrocinador Int Primary Key Identity(1,1),
    NombrePatrocinador Nvarchar(100) Not Null Unique,
    TipoPatrocinador Nvarchar(40) Not Null Check (TipoPatrocinador In ('Empresa', 'Instituci�n')),
    Contacto Nvarchar(100)
);
Go

-- ============================================
-- Tabla: Exhibicion
Create Table Exhibicion (
    Id_Exhibicion Int Primary Key Identity(1,1),
    NombreExhibicion Nvarchar(100) Not Null Unique,
    Tematica Nvarchar(120),
    CapacidadEstimada Int Check (CapacidadEstimada >= 0),
    Id_Patrocinador Int Null,
    Foreign Key (Id_Patrocinador) References Patrocinador(Id_Patrocinador)
);
Go

-- ============================================
-- Tabla: VisitaGuiada
Create Table VisitaGuiada (
    Id_VisitaGuiada Int Primary Key Identity(1,1),
    FechaVisita Date Not Null Default(Getdate()),
    NombreInstitucion Nvarchar(100) Not Null,
    CantidadPersonas Int Not Null Check (CantidadPersonas > 0),
    Id_Guia Int Not Null,
    Id_Exhibicion Int Not Null,
    Foreign Key (Id_Guia) References Empleado(Id_Empleado),
    Foreign Key (Id_Exhibicion) References Exhibicion(Id_Exhibicion)
);
Go

-- ============================================
-- Tabla: Mantenimiento
Create Table Mantenimiento (
    Id_Mantenimiento Int Primary Key Identity(1,1),
    FechaTrabajo Date Not Null Default(Getdate()),
    Descripcion Nvarchar(200) Not Null,
    Costo Decimal(8,2) Not Null Check (Costo >= 0),
    Id_Empleado Int Not Null,
    Id_Exhibicion Int Not Null,
    Foreign Key (Id_Empleado) References Empleado(Id_Empleado),
    Foreign Key (Id_Exhibicion) References Exhibicion(Id_Exhibicion)
);
Go

-- ============================================
-- Tabla: Finanza
Create Table Finanza (
    Id_Finanza Int Primary Key Identity(1,1),
    TipoRegistro Nvarchar(20) Not Null Check (TipoRegistro In ('Ingreso', 'Egreso')),
    Concepto Nvarchar(80) Not Null Check (Concepto In ('Boleto', 'Patrocinio', 'Mantenimiento')),
    Monto Decimal(10,2) Not Null Check (Monto >= 0),
    FechaRegistro Date Not Null Default(Getdate()),
    Id_Boleto Int Null,
    Id_Patrocinador Int Null,
    Id_Mantenimiento Int Null,
    Foreign Key (Id_Boleto) References Boleto(Id_Boleto),
    Foreign Key (Id_Patrocinador) References Patrocinador(Id_Patrocinador),
    Foreign Key (Id_Mantenimiento) References Mantenimiento(Id_Mantenimiento)
);
Go

-- ============================================
-- �ndices adicionales
Create Index IX_Boleto_IdVisitante On Boleto(Id_Visitante);
Go

Create Index IX_VisitaGuiada_IdExhibicion On VisitaGuiada(Id_Exhibicion);
Go

Create Index IX_Mantenimiento_IdEmpleado On Mantenimiento(Id_Empleado);
Go
-- Justificaci�n:
-- 1. Aceleran consultas por visitante, exhibici�n o empleado.
-- 2. Mejoran rendimiento en uniones.
-- 3. Reducen tiempo en generaci�n de reportes.

-- ============================================
-- Roles de seguridad
Create Role Rol_Empleado;
Create Role Rol_Administrador;
Go

-- Permisos para empleados
Grant Select On Visitante To Rol_Empleado;
Grant Select On Exhibicion To Rol_Empleado;
Grant Select, Insert On Boleto To Rol_Empleado;
Go

-- Permisos para administradores
Grant Select, Insert, Update, Delete On Schema::dbo To Rol_Administrador;
Go

-- ============================================
-- Tabla: Bit�cora
Create Table Bitacora (
    Id_Log Int Primary Key Identity(1,1),
    Accion Nvarchar(50) Not Null,
    Usuario Nvarchar(60) Not Null,
    Fecha DateTime Not Null Default(Getdate()),
    TablaAfectada Nvarchar(60) Not Null
);
Go

--================Procedimientos Almacenados (SP) y Triggers====================

-- SP1: Registrar una compra de boleto con inserci�n autom�tica en Finanza.
create procedure SP1_RegistrarCompraBoleto
    @TipoBoleto Nvarchar(20),
    @CostoTotal Decimal(8,2),
    @MetodoPago Nvarchar(30),
    @Id_Visitante Int
as
begin
    set nocount on;
    declare @Id_Boleto_Nuevo int;

    begin try
        begin transaction;

        -- 1. Insertar el Boleto
        insert into Boleto (TipoBoleto, CostoTotal, MetodoPago, Id_Visitante)
        values (@TipoBoleto, @CostoTotal, @MetodoPago, @Id_Visitante);

        -- Obtener el ID del boleto reci�n insertado
        set @Id_Boleto_Nuevo = SCOPE_IDENTITY();

        -- 2. Insertar el Ingreso en Finanza (autom�tico)
        -- El TipoRegistro es 'Ingreso' y el Concepto es 'Boleto'
        insert into Finanza (TipoRegistro, Concepto, Monto, Id_Boleto)
        values ('Ingreso', 'Boleto', @CostoTotal, @Id_Boleto_Nuevo);

        commit transaction;
        select 'Boleto y registro de Finanza creados exitosamente.' as Resultado, @Id_Boleto_Nuevo as Id_Boleto_Creado;
    end try
    begin catch
        if @@TRANCOUNT > 0
            rollback transaction;

        throw; -- Re-lanza el error
        return -1;
    end catch
end
go


-- SP2: registrar mantenimiento y reflejar gasto en finanza.
create procedure SP2_RegistrarMantenimientoYGasto
    @Descripcion nvarchar(200),
    @Costo decimal(8,2),
    @Id_Empleado int,
    @Id_Exhibicion int
as
begin
    set nocount on;
    declare @Id_Mantenimiento_Nuevo int;

    -- validar que el costo no sea negativo (aunque la tabla Mantenimiento ya tiene un CHECK)
    if @Costo < 0
    begin
        raiserror('el costo del mantenimiento no puede ser negativo.', 16, 1);
        return;
    end

    begin try
        begin transaction;

        -- 1. insertar el mantenimiento
        insert into Mantenimiento (Descripcion, Costo, Id_Empleado, Id_Exhibicion)
        values (@Descripcion, @Costo, @Id_Empleado, @Id_Exhibicion);

        -- obtener el ID del mantenimiento reci�n insertado
        set @Id_Mantenimiento_Nuevo = scope_identity();

        -- 2. reflejar el egreso en finanza (si el costo es > 0)
        if @Costo > 0
        begin
            -- el TipoRegistro es 'Egreso' y el Concepto es 'Mantenimiento'
            insert into Finanza (TipoRegistro, Concepto, Monto, Id_Mantenimiento)
            values ('Egreso', 'Mantenimiento', @Costo, @Id_Mantenimiento_Nuevo);
        end

        commit transaction;
        select 'Mantenimiento y registro de Finanza (si aplica) creados exitosamente.' as Resultado, @Id_Mantenimiento_Nuevo as Id_Mantenimiento_Creado;
    end try
    begin catch
        if @@trancount > 0
            rollback transaction;

        throw;
        return -1;
    end catch
end
go

-- SP3: consultar ingresos totales del d�a, agrupando por tipo de registro.
create procedure SP3_ConsultarIngresosDiarios
as
begin
    set nocount on;

    select
        Concepto,
        sum(Monto) as TotalIngreso
    from
        Finanza
    where
        TipoRegistro = 'Ingreso'
        and cast(FechaRegistro as date) = cast(getdate() as date) -- ingresos del d�a de hoy
    group by
        Concepto
    order by
        Concepto;

    -- opcional: tambi�n se puede calcular el ingreso total general del d�a
    select
        'Total General Ingresos del D�a' as Concepto,
        sum(Monto) as TotalIngresoGeneral
    from
        Finanza
    where
        TipoRegistro = 'Ingreso'
        and cast(FechaRegistro as date) = cast(getdate() as date);
end
go

-- trigger 1: en Mantenimiento, registrar autom�ticamente en la tabla Log (Bitacora) cuando se agregue un nuevo mantenimiento.
create trigger TR_Mantenimiento_Insert_Log
on Mantenimiento
after insert
as
begin
    set nocount on;

    insert into Bitacora (Accion, Usuario, TablaAfectada)
    select
        'INSERT',
        system_user, -- funci�n para obtener el usuario de la base de datos
        'Mantenimiento'
    from
        Inserted; -- la tabla 'inserted' contiene las filas que se acaban de insertar
end
go

-- trigger 2: en Finanza, validar que el monto no sea negativo antes de insertar.
create trigger TR_Finanza_Monto_NoNegativo
on Finanza
instead of insert -- reemplaza la acci�n de inserci�n
as
begin
    set nocount on;

    -- 1. verificar si hay montos negativos
    if exists (select 1 from Inserted where Monto < 0)
    begin
        -- si hay, lanza un error y no inserta
        raiserror('error: el monto de Finanza no puede ser negativo. la inserci�n ha sido cancelada por el trigger.', 16, 1);
        return;
    end
    else
    begin
        -- 2. si no hay montos negativos, realiza la inserci�n original
        insert into Finanza (TipoRegistro, Concepto, Monto, FechaRegistro, Id_Boleto, Id_Patrocinador, Id_Mantenimiento)
        select TipoRegistro, Concepto, Monto, FechaRegistro, Id_Boleto, Id_Patrocinador, Id_Mantenimiento
        from Inserted;
    end
end
go

-- caso de transacci�n 1: �xito (commit)
print '--- inicio caso de �xito (commit) ---';

begin transaction
begin try
    -- 1. insertar un visitante
    insert into Visitante (TipoVisitante) values ('Adulto joven');
    declare @Id_Visitante_Exito int = scope_identity();

    -- 2. insertar un boleto
    insert into Boleto (TipoBoleto, CostoTotal, MetodoPago, Id_Visitante)
    values ('Adulto', 25.00, 'Tarjeta', @Id_Visitante_Exito);
    
    -- si todo es exitoso, se confirma la transacci�n
    commit transaction;
    print 'transacci�n exitosa: los datos han sido guardados permanentemente.';
end try
begin catch
    -- si ocurre alg�n error, se revierte
    if @@trancount > 0
        rollback transaction;
    
    print 'transacci�n fallida: ocurri� un error y se hizo rollback.';
    throw;
end catch
go

-- verificar resultado (debe existir un nuevo visitante y boleto)
select * from Visitante where TipoVisitante = 'Adulto joven' order by Id_Visitante desc;
select * from Boleto order by Id_Boleto desc;

-- caso de transacci�n 2: error (rollback)
print '--- inicio caso de error (rollback) ---';

-- contamos antes del intento de ROLLBACK
declare @Count_Boleto_Antes int;
select @Count_Boleto_Antes = count(*) from Boleto;
print 'total de boletos antes del intento de rollback: ' + cast(@Count_Boleto_Antes as nvarchar);

begin transaction
begin try
    -- 1. insertar un visitante con un valor inv�lido (fallar� por la restricci�n CHECK)
    insert into Visitante (TipoVisitante) values ('Turista Extranjero'); -- valor no permitido

    -- 2. si la inserci�n anterior fall�, esta l�nea no se ejecutar� o la transacci�n ya estar� en estado de error
    insert into Boleto (TipoBoleto, CostoTotal, MetodoPago, Id_Visitante)
    values ('Adulto', 25.00, 'Tarjeta', scope_identity());
    
    -- si llega aqu�, significa que fall� la prueba de error
    commit transaction;
    print 'transacci�n fallida en la prueba de error: no ocurri� la falla esperada.';
end try
begin catch
    -- si ocurre el error esperado (o cualquier otro error), se revierte
    if @@trancount > 0
        rollback transaction;
    
    print 'transacci�n fallida por error de restricci�n: se revirti� la operaci�n (rollback).';
    -- opcional: mostrar el error
    -- select error_message() as MensajeDeError;
end catch
go

-- verificar resultado (la cuenta de boletos no debe haber cambiado)
declare @Count_Boleto_Despues int;
select @Count_Boleto_Despues = count(*) from Boleto;
print 'total de boletos despu�s del intento de rollback: ' + cast(@Count_Boleto_Despues as nvarchar);

-- el visitante no v�lido tampoco deber�a existir
select * from Visitante where TipoVisitante = 'Turista Extranjero';