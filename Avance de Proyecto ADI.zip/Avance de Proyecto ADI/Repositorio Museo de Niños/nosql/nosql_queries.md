
// MongoDB aggregation examples (run in mongo shell or MongoDB Compass aggregation tab)

// NoSQL Query 1: Total monto por concepto agrupado por mes (Finanza)
db.Finanza.aggregate([
  { $match: {} },
  { $project: { Año: { $year: { $toDate: "$FechaRegistro" } }, Mes: { $month: { $toDate: "$FechaRegistro" } }, Monto: "$Monto", Concepto: "$Concepto" } },
  { $group: { _id: { Año: "$Año", Mes: "$Mes", Concepto: "$Concepto" }, Total: { $sum: "$Monto" } } },
  { $sort: { "_id.Año": 1, "_id.Mes": 1, Total: -1 } }
]);

// NoSQL Query 2: Unir Boletos con Visitante y agrupar por TipoBoleto
db.Boleto.aggregate([
  { $lookup: { from: "Visitante", localField: "Id_Visitante", foreignField: "Id_Visitante", as: "visitante" } },
  { $unwind: "$visitante" },
  { $group: { _id: { TipoBoleto: "$TipoBoleto", MetodoPago: "$MetodoPago" }, Cantidad: { $sum: 1 }, Recaudado: { $sum: { $toDouble: "$CostoTotal" } } } },
  { $sort: { Recaudado: -1 } }
]);

// NoSQL Query 3: Mostrar mantenimientos con info del empleado y exhibicion
db.Mantenimiento.aggregate([
  { $lookup: { from: "Empleado", localField: "Id_Empleado", foreignField: "Id_Empleado", as: "empleado" } },
  { $lookup: { from: "Exhibicion", localField: "Id_Exhibicion", foreignField: "Id_Exhibicion", as: "exhibicion" } },
  { $unwind: "$empleado" },
  { $unwind: "$exhibicion" },
  { $project: { FechaTrabajo: 1, Descripcion: 1, Costo: 1, "Empleado": "$empleado.Nombre", "Exhibicion": "$exhibicion.NombreExhibicion" } }
]);
