
-- SQL Query 1: Total ingreso por mes (por concepto Boleto)
SELECT YEAR(F.FechaRegistro) AS Anio, MONTH(F.FechaRegistro) AS Mes, SUM(F.Monto) AS TotalMonto
FROM Finanza F
WHERE F.Concepto = 'Boleto'
GROUP BY YEAR(F.FechaRegistro), MONTH(F.FechaRegistro)
ORDER BY Anio, Mes;

-- SQL Query 2: Boletos por tipo y metodo de pago (JOIN Visitante)
SELECT B.TipoBoleto, B.MetodoPago, COUNT(*) AS Cantidad, SUM(B.CostoTotal) AS Recaudado
FROM Boleto B
JOIN Visitante V ON B.Id_Visitante = V.Id_Visitante
GROUP BY B.TipoBoleto, B.MetodoPago
ORDER BY Recaudado DESC;

-- SQL Query 3: Costos de mantenimiento por exhibicion (JOIN)
SELECT E.NombreExhibicion, SUM(M.Costo) AS TotalMantenimiento, COUNT(*) AS CantidadTrabajos
FROM Mantenimiento M
JOIN Exhibicion E ON M.Id_Exhibicion = E.Id_Exhibicion
GROUP BY E.NombreExhibicion
ORDER BY TotalMantenimiento DESC;
