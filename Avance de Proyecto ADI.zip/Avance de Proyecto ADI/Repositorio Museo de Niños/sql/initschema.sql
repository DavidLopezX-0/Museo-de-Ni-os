-- DDL for Museo (simplified). Use the original full DDL when available.
CREATE DATABASE Museo;
GO
USE Museo;
GO
-- (Tables: Visitante, Boleto, Empleado, Patrocinador, Exhibicion, VisitaGuiada, Mantenimiento, Finanza, Bitacora)
-- Please paste the full DDL provided by the instructor if needed.
