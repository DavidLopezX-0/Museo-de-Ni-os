Coloque capturas de pantalla de resultados de consultas aquí. Ejemplo: resultados SQL, logs de mongoimport, exports CSV.
