
# Museo - Dataset y Scripts

Estructura del repositorio generada:
- /sql
  - initschema.sql   (DDL original provided by user - add manually or use included file)
  - inserts_museo.sql  (INSERT statements generated)
- /nosql
  - Visitante.json
  - Empleado.json
  - Patrocinador.json
  - Exhibicion.json
  - Boleto.json
  - VisitaGuiada.json
  - Mantenimiento.json
  - Finanza.json
  - Bitacora.json
- /evidencias
  - (colocar capturas, logs, exports aquí)

## Cómo usar

### SQL Server (local)
1. Crear la base de datos `Museo` y ejecutar el DDL (use the provided DDL if you have it).
2. Ejecutar `inserts_museo.sql`. Si usa SQL Server Management Studio, el script incluye `SET IDENTITY_INSERT` por tabla para mantener los ids generados.
3. Verificar los conteos: `SELECT COUNT(*) FROM Visitante;` etc. (debería sumar >= 100 filas distribuidas).

### MongoDB (NoSQL)
1. Crear una base de datos `museo_nosql`.
2. Importar cada JSON: `mongoimport --db museo_nosql --collection Visitante --file Visitante.json --jsonArray` (y así con cada archivo).
3. Ejecutar agregaciones de ejemplo (ver archivo `nosql_queries.md` para ejemplos).

## Consultas incluidas (ejemplos)
- 3 SQL con JOINs y agregaciones (archivo `sql/queries_sql_examples.md`)
- 3 NoSQL (MongoDB) con aggregate/lookup (archivo `nosql/nosql_queries.md`)

## Evidencias
- Tome capturas de pantallas de los resultados de cada consulta y súbalas en `/evidencias`. También puede exportar resultados a CSV con `bcp` o `SELECT ... INTO OUTFILE` dependiendo del motor.

